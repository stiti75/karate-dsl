function fn() {
  var env = karate.env; // get java system property 'karate.env'
  karate.log('karate.env system property was:', env);
  if (!env) {
    env = 'dev'; // a custom 'intelligent' default
  }
  var config = { // base config JSON
    appId: 'my.app.id',
    appSecret: 'my.secret',
    baseUrl: karate.properties['URL_API'],
    bearerToken: 'eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJtMDAwMDAiLCJleHAiOjE2NTUxOTMwNjcsImlhdCI6MTY1NDU4ODI2N30.l12I_Im54B7pQihhiKBR62of7UE6e9Ilgyi1cpt1Rzkd3Jm8re6_oKwOOJ03ahO0PkOjp_VU7w0zkIiLOwm3zg'
  };
  if (env == 'staging') {
    // over-ride only those that need to be
    config.baseUrl =  karate.properties['URL_API'];
  } else if (env == 'masterstaging') {
    config.baseUrl =  karate.properties['URL_API'];
  }
  if (karate.properties['BEARER_TOKEN'] != null) {
    config.bearerToken =  karate.properties['BEARER_TOKEN'];
  }
  // don't waste time waiting for a connection or if servers don't respond within 5 seconds
  karate.configure('connectTimeout', 5000);
  karate.configure('readTimeout', 5000);
  karate.log('Config :', config);
  return config;
}